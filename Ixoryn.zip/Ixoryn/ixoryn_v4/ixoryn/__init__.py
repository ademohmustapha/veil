"""
Ixoryn — Advanced Security & Intelligence Platform
Author   : Ademoh Mustapha Onimisi
Copyright: © 2026 Ademoh Mustapha Onimisi. All rights reserved.
License  : MIT
GitHub   : https://github.com/ademoh-mustapha/ixoryn
"""

__version__   = "1"
__author__    = "Ademoh Mustapha Onimisi"
__copyright__ = "Copyright © 2026 Ademoh Mustapha Onimisi"
__license__   = "MIT"
__url__       = "https://github.com/ademoh-mustapha/ixoryn"
